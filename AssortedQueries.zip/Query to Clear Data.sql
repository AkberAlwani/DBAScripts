/* The sp is spPTIPurgeTableData and it takes the following optional parameters.  If you run with no parameters on the company db it will truncate all the transaction tables only (basically what you have been doing).

@xDatabase  VARCHAR(60)  = null  -- CONTROL, COMPANY, PTIMaster  
,@xPurgeSetup INT    = 0  -- If set to 1 then the setup tables will be cleared as well.  
,@xOutputOnly INT    = 0  -- If set to 1 then the truncate statements will be returned only.  
,@xModule  VARCHAR(255) = null -- AP,AR,BUD,CAT,EXP,GL,IFC,IV,PA,PM,PO,PTI,RCV,RFQ,RQ,TE,VC,WC /*


exec spPTIPurgeTableData   

exec spPTIFixPrimaryKey
