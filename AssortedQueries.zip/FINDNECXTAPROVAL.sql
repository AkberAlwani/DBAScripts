
Select D.idfRQHeaderKey as Requisition, Sec.idfDescription as  approver ,wcl.idfDescription AS APPROVAL , wcl.idfFlagParallelApr as Parallel from WCAprPath	P
Inner Join RQDetail D on D.idfRQDetailKey=P.idfLinkTableKey
Inner Join WCRRGroupLineUp RR on RR.idfWCRRGroupLineUpKey=P.idfWCRRGroupLineUpKey
Inner Join WCLineUpSec lnup on lnup.idfWCLineUpKey = RR.idfWCLineUpKey
Inner Join WCLineUp WCL on WCL.idfWCLineUpKey=lnup.idfWCLineUpKey
Inner Join WCRole Sec on Sec.idfWCRoleKey=lnup.idfWCRoleKey
Where D.idfRQSessionKey>100 and d.idfRQSessionKey<130 


Select * from WCLineUpSec