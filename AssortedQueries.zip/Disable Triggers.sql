LTER TABLE GL40200 disable trigger IFC_tuidGLSegmentDtl 
ALTER TABLE GL00100 disable trigger IFC_tuidGLSegmentDtlCombination
ALTER TABLE SY00300 disable trigger IFC_tuidGLSegmentHdr


ALTER TABLE PM10000 disable trigger tuidPM10000