EXEC spWCRRTemplateInit
GO
EXEC spWCRRTemplateDtlSetRuleAll
Go