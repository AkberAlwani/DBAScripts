--Vendor Code

select * from master..sysmessages where error in (3621,8152)